<?php

// Simple loader file
// Library downloaded directly from https://github.com/tubalmartin/YUI-CSS-compressor-PHP-port

require( __DIR__ . '/Colors.php' );
require( __DIR__ . '/Utils.php' );
require( __DIR__ . '/Minifier.php' );
