# VIP Go mu-plugins

This is the mu-plugins folder for VIP Go, assembled without submodules for convenience.

Please see our documentation on setting up your [local development environment](https://docs.wpvip.com/how-tos/set-up-a-vip-go-local-development-site/).

## Pull Requests

If you wish to submit a pull request for any code here, please do so on the development repo at [Automattic/vip-go-mu-plugins](https://github.com/Automattic/vip-go-mu-plugins/).

## PHPDoc

You can find selective PHPDoc documentation here: https://automattic.github.io/vip-go-mu-plugins/
