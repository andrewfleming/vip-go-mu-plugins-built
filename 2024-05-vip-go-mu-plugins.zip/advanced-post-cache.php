<?php
/*
Plugin Name: Advanced Post Caching
Description: Cache post queries.
Version: 0.2
Author: Automattic
Author URI: http://automattic.com/
*/

if ( ! defined( 'WP_RUN_CORE_TESTS' ) || ! WP_RUN_CORE_TESTS ) {
	require_once __DIR__ . '/advanced-post-cache/advanced-post-cache.php';
}
