<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '91bb1afbdad1b1b22924');
