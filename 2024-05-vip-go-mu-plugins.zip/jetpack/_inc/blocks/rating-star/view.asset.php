<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'd08ba384156b34a55ce0');
