<?php return array('dependencies' => array('wp-polyfill'), 'version' => '211983e7c0889099c52d');
