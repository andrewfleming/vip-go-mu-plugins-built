<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'dfb5a766d9008f6d8b91');
