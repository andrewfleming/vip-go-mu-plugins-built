<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '2a882f2c239bd818d017');
