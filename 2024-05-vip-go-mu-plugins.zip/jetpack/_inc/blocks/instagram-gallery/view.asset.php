<?php return array('dependencies' => array('wp-polyfill'), 'version' => '9478abc734adde1247b3');
