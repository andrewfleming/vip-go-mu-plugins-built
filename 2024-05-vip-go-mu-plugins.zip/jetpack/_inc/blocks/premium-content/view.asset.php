<?php return array('dependencies' => array('wp-polyfill'), 'version' => '20021c242e1d03e21edd');
