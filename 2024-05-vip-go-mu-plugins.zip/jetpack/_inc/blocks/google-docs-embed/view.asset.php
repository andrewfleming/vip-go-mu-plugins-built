<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '85fda931b8204a116d93');
