<?php return array('dependencies' => array('wp-polyfill'), 'version' => '84ef72d0b5d04d7726c9');
