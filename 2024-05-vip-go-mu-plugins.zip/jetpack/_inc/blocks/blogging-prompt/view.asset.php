<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'c338606afa1d9298a4fe');
