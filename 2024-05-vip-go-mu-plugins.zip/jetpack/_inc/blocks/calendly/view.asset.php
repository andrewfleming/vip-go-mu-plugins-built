<?php return array('dependencies' => array('wp-polyfill'), 'version' => '1920eabaec8a9a9d174e');
