<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'd893042b95edc7bb611a');
