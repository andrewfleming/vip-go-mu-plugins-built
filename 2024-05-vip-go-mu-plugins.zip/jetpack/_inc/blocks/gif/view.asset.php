<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'cfa333356a97995d0eaa');
