<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'a0c4d68dd0b73b386f8b');
