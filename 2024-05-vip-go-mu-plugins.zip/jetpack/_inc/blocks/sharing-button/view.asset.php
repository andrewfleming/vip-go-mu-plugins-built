<?php return array('dependencies' => array('wp-polyfill'), 'version' => '6bf5b14eb8b2e51e2074');
