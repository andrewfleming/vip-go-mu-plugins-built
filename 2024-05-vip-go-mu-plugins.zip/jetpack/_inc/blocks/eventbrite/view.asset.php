<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'e2ca4ca2fe388085d1b5');
