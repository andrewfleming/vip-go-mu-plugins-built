<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '534b4ceff81c737bb0c0');
