<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'f363567b54a1a06949a8');
