<?php return array('dependencies' => array('wp-polyfill'), 'version' => '7d467b551780bf0399bf');
