<?php return array('dependencies' => array('wp-polyfill'), 'version' => '0a0aeb0ea5dc58158021');
