<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '2c01111443a713697b09');
