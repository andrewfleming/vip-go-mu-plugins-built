<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'ec78a0ad105e45c0cbab');
