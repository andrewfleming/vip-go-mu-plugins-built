<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '18dc1ff8c51522b0cbfb');
