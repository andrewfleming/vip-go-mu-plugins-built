<?php return array('dependencies' => array('wp-polyfill'), 'version' => '44d5ef2bdc48d09ce19b');
