<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '5210f83dfb816f5faa67');
