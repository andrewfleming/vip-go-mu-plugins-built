<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '2c574df699677fdc8f42');
