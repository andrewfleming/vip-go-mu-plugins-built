<?php
/**
 * Plugin Name: Admin Notice
 * Description: Adds dismissible notice in admin area
 * Version:     0.1.0
 * Author:      WordPress VIP
 * Author URI:  https://wpvip.com
 * License:     GPLv2 or later
 *
 * @package Automattic\VIP\AdminNotice
 */
require_once __DIR__ . '/admin-notice/admin-notice.php';
