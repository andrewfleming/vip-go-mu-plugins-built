<?php

namespace Automattic\VIP\Debug;

require_once __DIR__ . '/logger.php';
require_once __DIR__ . '/debug-mode.php';
require_once __DIR__ . '/not-proxied-flag.php';
